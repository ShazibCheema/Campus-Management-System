Campus Management System an Android App best for your semester project written in java. In this app what you can do as a Teacher is Mark attendance,Upload result and as a Student you can view them all
It invloves Firebase integeration for authentication and firestore for handling data

![WhatsApp Image 2023-12-20 at 7 46 11 PM](https://github.com/CodeWithAbdurrehman/CampusManagementSystem/assets/108186523/c55591d9-73db-4a92-83a6-d5ca63a8e920)
![WhatsApp Image 2023-12-20 at 7 46 12 PM](https://github.com/CodeWithAbdurrehman/CampusManagementSystem/assets/108186523/67c4c720-53c8-4a34-a070-18cefc875e9d)
